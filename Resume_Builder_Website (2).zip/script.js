function createFieldSet(placeholders, classes) {
  const div = document.createElement("div");
  placeholders.forEach((ph, i) => {
    const inp = document.createElement("input");
    inp.placeholder = ph;
    inp.className = classes[i];
    inp.style.marginRight = "8px";
    div.appendChild(inp);
  });
  const removeBtn = document.createElement("button");
  removeBtn.type = "button";
  removeBtn.textContent = "Remove";
  removeBtn.className = "blue-btn";
  removeBtn.style.background = "#c31621";
  removeBtn.style.margin = "4px 0 0 6px";
  removeBtn.onclick = () => div.remove();
  div.appendChild(removeBtn);
  return div;
}

window.onload = function () {
  document.getElementById("addExp").onclick = function () {
    document.getElementById("expList").appendChild(
      createFieldSet(
        ["Job Title", "Company", "Location", "From", "To", "Description"],
        ["exp-role", "exp-comp", "exp-loc", "exp-from", "exp-to", "exp-desc"]
      )
    );
  };
  document.getElementById("addIntern").onclick = function () {
    document.getElementById("internList").appendChild(
      createFieldSet(
        ["Internship Title", "Organization", "Location", "From", "To", "Description"],
        ["intern-role", "intern-comp", "intern-loc", "intern-from", "intern-to", "intern-desc"]
      )
    );
  };
  document.getElementById("addLead").onclick = function () {
    document.getElementById("leadList").appendChild(
      createFieldSet(
        ["Role", "Organization", "Location", "From", "To", "Description"],
        ["lead-role", "lead-comp", "lead-loc", "lead-from", "lead-to", "lead-desc"]
      )
    );
  };
  document.getElementById("addEdu").onclick = function () {
    document.getElementById("eduList").appendChild(
      createFieldSet(
        ["Institution", "Month, Year", "Degree/Branch", "GPA/Notes", "Achievements"],
        ["edu-inst", "edu-time", "edu-deg", "edu-gpa", "edu-achv"]
      )
    );
  };
  document.getElementById("addProj").onclick = function () {
    document.getElementById("projList").appendChild(
      createFieldSet(
        ["Project Title", "Month, Year", "Role/Outcome/Description"],
        ["proj-title", "proj-time", "proj-detail"]
      )
    );
  };

  document.getElementById("resumeForm").onsubmit = function (e) {
    e.preventDefault();
    const name = document.getElementById("name").value || "";
    const phone = document.getElementById("phone").value || "";
    const email = document.getElementById("email").value || "";
    const linkedin = document.getElementById("linkedin").value || "";
    const location = document.getElementById("location").value || "";
    const summary = document.getElementById("summary").value || "";
    const skills = document.getElementById("skills").value.split(",").map(s => s.trim()).filter(Boolean);

    function extractSection(cid) {
      let items = document.getElementById(cid).children, out = [];
      for (let i = 0; i < items.length; ++i) {
        let vals = Array.from(items[i].querySelectorAll("input")).map(e => e.value);
        if (vals.length && vals.some(v => v.length)) out.push(vals);
      }
      return out;
    }
    const exp = extractSection("expList");
    const intern = extractSection("internList");
    const lead = extractSection("leadList");
    const edu = extractSection("eduList");
    const proj = extractSection("projList");

    let html = `<header><h1>${name}</h1><div class="contact-info">
      ${phone} | ${email}${linkedin ? " | " + linkedin : ""}${location ? " | " + location : ""}</div></header>`;
    html += `<section class="resume-section"><h2>Summary</h2><p>${summary}</p></section>`;
    if (exp.length) {
      html += `<section class="resume-section"><h2>Professional Experience</h2>`;
      exp.forEach(e => { html += `<div><b>${e[0]}</b>, ${e[1]} (${e[3]} - ${e[4]}) | ${e[2]}<ul><li>${e[5]}</li></ul></div>`; });
      html += `</section>`;
    }
    if (intern.length) {
      html += `<section class="resume-section"><h2>Internship</h2>`;
      intern.forEach(i => { html += `<div><b>${i[0]}</b>, ${i[1]} (${i[3]} - ${i[4]}) | ${i[2]}<ul><li>${i[5]}</li></ul></div>`; });
      html += `</section>`;
    }
    if (lead.length) {
      html += `<section class="resume-section"><h2>Team Lead</h2>`;
      lead.forEach(l => { html += `<div><b>${l[0]}</b>, ${l[1]} (${l[3]} - ${l[4]}) | ${l[2]}<ul><li>${l[5]}</li></ul></div>`; });
      html += `</section>`;
    }
    if (edu.length) {
      html += `<section class="resume-section"><h2>Education</h2>`;
      edu.forEach(ed => { html += `<div><b>${ed[0]}</b> (${ed[1]})<br>${ed[2]}<br>${ed[3] ? "GPA/Notes: " + ed[3] + "<br>" : ""}${ed[4]}</div>`; });
      html += `</section>`;
    }
    if (skills.length) {
      html += `<section class="resume-section"><h2>Skills</h2><ul>`;
      skills.forEach(s => { html += `<li>${s}</li>`; });
      html += `</ul></section>`;
    }
    if (proj.length) {
      html += `<section class="resume-section"><h2>Projects</h2><ul>`;
      proj.forEach(p => { html += `<li><b>${p[0]}</b> (${p[1]}):<br>${p[2]}</li>`; });
      html += `</ul></section>`;
    }

    document.getElementById("resumePreview").innerHTML = html;
    document.getElementById("resumeForm").style.display = "none";
    document.getElementById("resumePreview").style.display = "block";
    document.getElementById("editBtn").style.display = "inline-block";
    document.getElementById("downloadBtn").style.display = "inline-block";
  };

  document.getElementById("editBtn").onclick = function () {
    document.getElementById("resumePreview").style.display = "none";
    document.getElementById("resumeForm").style.display = "block";
    document.getElementById("editBtn").style.display = "none";
    document.getElementById("downloadBtn").style.display = "none";
  };

  document.getElementById("downloadBtn").onclick = function () {
    window.print();
  };
};
